# -*- coding: utf-8 -*-
import json,os,subprocess,sys
from pathlib import Path
run=Path(__file__).resolve().parent
m=json.loads((run/'manifest.json').read_text())
env=os.environ.copy();env['K24_ROOT']=str(run.parents[2]);env['JAVA_HOME']=m['jdk_home'];env['MAVEN_OPTS']='-Djava.net.preferIPv4Stack=true -Djava.net.preferIPv6Addresses=false'
if os.environ.get('K24_LOAD_MODEL_CONFIG')=='1':
    from dotenv import dotenv_values
    root=run.parents[2]
    v=dotenv_values(root/'.env')
    for name in ['LLM_API_KEY','LLM_MODEL_NAME']:env[name]=v[name]
    env['LLM_BASE_URL']='https://api.deepseek.com'
    env['K24_ROOT']=str(root)
cmd=[str(Path(m['maven_home'])/'bin/mvn'),'-B','-ntp','-s',str(run/'maven-settings.xml'),'-Dmaven.repo.local='+str(run/'repository')]+sys.argv[1:]
raise SystemExit(subprocess.run(cmd,env=env).returncode)
