package local.k24;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.modelcontextprotocol.client.McpClient;
import io.modelcontextprotocol.client.transport.ServerParameters;
import io.modelcontextprotocol.client.transport.StdioClientTransport;
import io.modelcontextprotocol.json.McpJsonMapper;
import io.modelcontextprotocol.spec.McpSchema;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;

/** Local read-only probe using the Spring AI 1.1.2 MCP dependency. */
public class McpProbe {
    public static void main(String[] args) throws Exception {
        try {
            run(args);
        } finally {
            // Probe process only. K17 must own the service worker lifecycle.
            reactor.core.scheduler.Schedulers.shutdownNow();
        }
    }

    private static void run(String[] args) throws Exception {
        Path root = Path.of(args[0]).toAbsolutePath();
        Path run = Path.of(args[1]).toAbsolutePath();
        Files.createDirectories(run);
        var params = ServerParameters.builder(root.resolve(".venv/bin/python").toString())
            .args("-m", "ckp.mcp_server")
            .env(Map.of("PYTHONPATH", root.resolve("src").toString(),
                "CKP_DATA", run.resolve("empty-data").toString(),
                "CKP_OUTPUT", run.resolve("output").toString())).build();
        var transport = new StdioClientTransport(params, McpJsonMapper.createDefault());
        var client = McpClient.sync(transport).requestTimeout(Duration.ofSeconds(20)).build();
        Map<String, Object> record = new LinkedHashMap<>();
        try {
            var init = client.initialize();
            record.put("initialize", init);
            var list = client.listTools();
            record.put("tool_count", list.tools().size());
            record.put("tools", list.tools());
            for (String name : new String[]{"distill_stages", "product_material_list"}) {
                var value = client.callTool(McpSchema.CallToolRequest.builder()
                    .name(name).arguments(Map.of()).build());
                if (Boolean.TRUE.equals(value.isError())) throw new IllegalStateException(name + " returned MCP error");
                record.put(name, value);
            }
        } finally {
            client.closeGracefully();
        }
        try (var paths = Files.exists(run.resolve("empty-data")) ? Files.walk(run.resolve("empty-data")) : java.util.stream.Stream.<Path>empty()) {
            record.put("isolated_data_files", paths.filter(Files::isRegularFile).map(Path::toString).toList());
        }
        new ObjectMapper().writerWithDefaultPrettyPrinter().writeValue(run.resolve("mcp-result.json").toFile(), record);
        System.out.println("record=" + run.resolve("mcp-result.json"));
    }
}
