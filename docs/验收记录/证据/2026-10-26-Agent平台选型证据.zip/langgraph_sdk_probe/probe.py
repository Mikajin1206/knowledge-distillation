# -*- coding: utf-8 -*-
"""LangGraph OSS + existing MCP SDK boundary, without LangChain MCP adapter."""
import asyncio,json
from pathlib import Path
from typing import TypedDict
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client
from langgraph.graph import StateGraph,START,END
ROOT=Path(__file__).resolve().parents[3]
RUN=Path(__file__).resolve().parent
class State(TypedDict,total=False):evidence:dict; rejected_hash:bool
async def check():
    params=StdioServerParameters(command=str(ROOT/'.venv/bin/python'),args=[str(RUN.parent/'fixture_mcp.py')],env={'K24_RUN_DIR':str(RUN)})
    async with stdio_client(params) as (read,write):
        async with ClientSession(read,write) as session:
            await session.initialize()
            found=await session.call_tool('search_product_materials',{'query':'synthetic订单变更'})
            data=found.structured_content
            if data is None:data=json.loads(next(x.text for x in found.content if x.type=='text'))
            hit=data['results'][0]
            args={k:hit[k] for k in ['material_id','revision','source_sha256']}
            args.update(section_ids=['section_rules'],full_document=False)
            content=await session.call_tool('read_product_material',args)
            assert not content.is_error
            bad=await session.call_tool('read_product_material',{**args,'source_sha256':'0'*64})
            assert bad.is_error
            return {'evidence':hit,'rejected_hash':bad.is_error}
def gateway(state):return asyncio.run(check())
b=StateGraph(State);b.add_node('knowledge',gateway);b.add_edge(START,'knowledge');b.add_edge('knowledge',END)
out=b.compile().invoke({})
assert out['evidence']['material_id']=='synthetic-manual' and out['rejected_hash']
(RUN/'result.json').write_text(json.dumps({'status':'passed','adapter':'standard mcp.ClientSession','no_langchain_mcp_adapter':True,'evidence':out},ensure_ascii=False,indent=2))
print('PASS: LangGraph node + standard MCP SDK search/read + explicit isError hash rejection')
