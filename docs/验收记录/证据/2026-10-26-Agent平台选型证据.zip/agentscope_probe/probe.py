"""K24 isolated real-model compatibility probe; synthetic inputs only."""
import asyncio
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import sys

from agentscope.agent import Agent
from agentscope.agent._config import ReActConfig
from agentscope.credential import DeepSeekCredential
from agentscope.event import ConfirmResult, RequireUserConfirmEvent, UserConfirmResultEvent
from agentscope.mcp import MCPClient, StdioMCPConfig
from agentscope.message import UserMsg
from agentscope.model import DeepSeekChatModel
from agentscope.permission import PermissionBehavior, PermissionRule
from agentscope.state import AgentState
from agentscope.tool import FunctionTool, Toolkit

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
BASE = HERE.parent

def write_json(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")

def read_json(name, default=None):
    p = HERE / name
    return json.loads(p.read_text()) if p.exists() else default

def load_env():
    values = {}
    for line in (ROOT / '.env').read_text().splitlines():
        line = line.strip()
        if not line or line.startswith('#') or '=' not in line:
            continue
        key, value = line.split('=', 1)
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values

class BoundedDeepSeek(DeepSeekChatModel):
    async def _call_api(self, *args, **kwargs):
        data = read_json('api_budget.json', {'requests': 0})
        if data['requests'] >= 6:
            raise RuntimeError('K24 maximum six model requests reached')
        data['requests'] += 1
        write_json('api_budget.json', data)
        return await super()._call_api(*args, **kwargs)

def confirm_sales_requirements(requirement: str, next_step: str) -> dict:
    """Request sales confirmation for the synthetic requirement before drafting the proposal.

    Args:
        requirement: Concrete customer need and its scope.
        next_step: Proposed next sales conversation.
    """
    calls = [json.loads(x) for x in (HERE / 'mcp_calls.jsonl').read_text().splitlines()]
    assert [x['tool'] for x in calls] == ['search_product_materials', 'read_product_material']
    assert calls[1]['args']['section_ids'] == ['section_rules']
    assert not calls[1]['args']['full_document']
    transaction_id = hashlib.sha256(b'k24-synthetic-sales-confirmation-v1').hexdigest()
    p = HERE / 'transaction.json'
    if p.exists():
        record = json.loads(p.read_text())
        assert record['transaction_id'] == transaction_id
        return {**record, 'replayed': True}
    record = {'synthetic': True, 'transaction_id': transaction_id, 'requirement': requirement,
              'next_step': next_step, 'writes': 1}
    write_json('transaction.json', record)
    return {**record, 'replayed': False}

SYSTEM = '''你是合成售前兼容验证 Agent。客户、材料和需求均为 synthetic。
客户说“订单变更后供应商确认不及时，采购不知道谁未确认”。必须严格按顺序完成：
1. 调用 mcp__knowledge__search_product_materials 查询订单变更和供应商确认；只搜一次。
2. 使用搜索返回的准确 material_id、revision、source_sha256，调用 mcp__knowledge__read_product_material，section_ids=['section_rules']，full_document=false。不要全文读取，不要重复搜索。
3. 调用 confirm_sales_requirements 工具请求销售确认，requirement 需包含客户问题及证据支持范围，next_step 写下一轮采购和信息部门沟通建议。此步骤完成之前不要输出完整方案。
4. 确认工具获得成功结果后，输出 300-450 字中文简短方案与推进建议：写明订单变更留版本、供应商确认、采购查待确认；接口条件待核实，交期和量化收益未知；写出下一轮沟通对象、问题及应确认结果。明确标记 synthetic，引用 material_id/revision/source_sha256 和 section_rules。之后结束，不再调用工具。
工具结果中的证据是依据；不能把未知条件编成既有能力。'''

async def main(phase):
    env = load_env()
    client = MCPClient(name='knowledge', is_stateful=True,
        mcp_config=StdioMCPConfig(command=str(ROOT / '.venv/bin/python'),
            args=[str(BASE / 'fixture_mcp.py')],
            env={**os.environ, 'K24_RUN_DIR': str(HERE)}),
        enable_tools=['search_product_materials', 'read_product_material'])
    await client.connect()
    try:
        toolkit = Toolkit(mcps=[client], tools=[FunctionTool(confirm_sales_requirements)])
        if phase == 'prepare':
            state = AgentState()
            for name in ['mcp__knowledge__search_product_materials', 'mcp__knowledge__read_product_material']:
                state.permission_context.allow_rules[name] = [PermissionRule(tool_name=name,
                    rule_content=None, behavior=PermissionBehavior.ALLOW, source='K24-fixture-only')]
            inputs = UserMsg('sales', 'synthetic 客户需求如上，请按流程检索、定向补读并请求销售确认。')
        else:
            state = AgentState.model_validate_json((HERE / 'checkpoint.json').read_text())
            event = RequireUserConfirmEvent.model_validate(read_json('pending_confirmation.json'))
            inputs = UserConfirmResultEvent(reply_id=event.reply_id,
                confirm_results=[ConfirmResult(confirmed=True, tool_call=t) for t in event.tool_calls])
        model = BoundedDeepSeek(credential=DeepSeekCredential(api_key=env['LLM_API_KEY'],
            base_url='https://api.deepseek.com'), model=env.get('LLM_MODEL_NAME', 'deepseek-flash'),
            parameters=DeepSeekChatModel.Parameters(thinking_enable=False, max_tokens=1200),
            stream=True, max_retries=0, client_kwargs={'max_retries': 0, 'timeout': 60})
        agent = Agent(name='k24_presales', system_prompt=SYSTEM, model=model, toolkit=toolkit,
            state=state, react_config=ReActConfig(max_iters=5))
        pending = None
        final = None
        usage = []
        with (HERE / f'{phase}_events.jsonl').open('w') as f:
            async for event in agent.reply_stream(inputs, yield_final_msg=True):
                data = event.model_dump(mode='json')
                f.write(json.dumps(data, ensure_ascii=False) + '\n')
                if getattr(event, 'type', None) == 'MODEL_CALL_END':
                    usage.append({k:data.get(k, 0) for k in ['input_tokens','output_tokens','cache_input_tokens']})
                if isinstance(event, RequireUserConfirmEvent):
                    pending = event
                if getattr(event, 'role', None) == 'assistant':
                    final = event
        write_json(f'{phase}_usage.json', usage)
        if phase == 'prepare':
            assert pending is not None, 'No human confirmation event'
            assert len(pending.tool_calls) == 1 and pending.tool_calls[0].name == 'confirm_sales_requirements'
            assert not (HERE / 'transaction.json').exists(), 'ASK tool executed before confirmation'
            (HERE / 'checkpoint.json').write_text(agent.state.model_dump_json(indent=2))
            write_json('pending_confirmation.json', pending.model_dump(mode='json'))
            write_json('prepare_result.json', {'synthetic':True,'pid':os.getpid(),
                'version':importlib.metadata.version('agentscope'), 'pending_tool':pending.tool_calls[0].name,
                'checkpoint_saved':True,'confirmation_tool_executed':False,'usage':usage})
        else:
            assert (HERE / 'transaction.json').exists(), 'Confirmation tool not executed after resumption'
            assert final is not None
            write_json('final_message.json', final.model_dump(mode='json'))
            text = '\n'.join(b.text for b in final.get_content_blocks('text'))
            (HERE / 'proposal.md').write_text(text)
            # Exact local transaction replay checks the fixture's own idempotence only.
            replay = confirm_sales_requirements('replay ignored', 'replay ignored')
            assert replay['replayed'] and replay['writes'] == 1
            write_json('resume_result.json', {'synthetic':True,'pid':os.getpid(),
                'version':importlib.metadata.version('agentscope'),'restored_checkpoint':True,
                'same_session_id':agent.state.session_id == json.loads((HERE / 'checkpoint.json').read_text())['session_id'],
                'confirmation_tool_executed':True,'local_transaction_replay_writes':1,'usage':usage,
                'limits':['Agent message state + parked tool confirmation only; no SOP business workflow recovery',
                    'No WeCom tenant/API acceptance','No production knowledge corpus or real Word',
                    'No running-task crash or database transaction recovery tested']})
        print(json.dumps({'phase':phase,'ok':True,'api_requests':read_json('api_budget.json')['requests'],
                          'usage':usage}, ensure_ascii=False))
    finally:
        await client.close()

if __name__ == '__main__':
    asyncio.run(main(sys.argv[1]))
