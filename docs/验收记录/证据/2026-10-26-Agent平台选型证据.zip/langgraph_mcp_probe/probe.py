"""Read-only LangChain MCP adapter probe, isolated from the real data store."""
import asyncio
import json
from pathlib import Path

from fastmcp.client.transports import StdioTransport
from langchain.mcp import MCPAdapter

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
BASE = HERE.parent


def plain(value):
    if isinstance(value, (str, int, float, bool, type(None))):
        return value
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if hasattr(value, "model_dump"):
        return plain(value.model_dump())
    return repr(value)


async def main():
    result = {"scope": "isolated read-only MCP discovery and direct tool calls; no model calls"}
    transport = StdioTransport(
        command=str(ROOT / ".venv/bin/python"),
        args=["-m", "ckp.mcp_server"],
        env={"PYTHONPATH": str(ROOT / "src"), "CKP_DATA": str(HERE / "empty-data"),
             "CKP_OUTPUT": str(HERE / "output")},
        cwd=str(ROOT), log_file=HERE / "real-server-stderr.log",
    )
    async with MCPAdapter(transport) as adapter:
        tools = await adapter.list_tools()
        by_name = {tool.name: tool for tool in tools}
        result["real_server"] = {
            "tool_count": len(tools), "tool_names": sorted(by_name),
            "schema": {name: by_name[name].args_schema.model_json_schema()
                       if hasattr(by_name[name].args_schema, "model_json_schema")
                       else plain(by_name[name].args_schema)
                       for name in ["distill_stages", "product_material_list", "read_product_material"]},
            "distill_stages": plain(await by_name["distill_stages"].ainvoke({})),
            "product_material_list": plain(await by_name["product_material_list"].ainvoke({})),
        }
    transport = StdioTransport(
        command=str(ROOT / ".venv/bin/python"), args=[str(BASE / "fixture_mcp.py")],
        env={"K24_RUN_DIR": str(HERE / "fixture")}, cwd=str(ROOT),
        log_file=HERE / "fixture-server-stderr.log",
    )
    async with MCPAdapter(transport) as adapter:
        tools = await adapter.list_tools()
        by_name = {tool.name: tool for tool in tools}
        fixture = {"tool_count": len(tools)}
        try:
            value = await by_name["read_product_material"].ainvoke({
                "material_id": "synthetic-manual", "revision": 1,
                "source_sha256": "0" * 64, "section_ids": ["section_rules"],
                "full_document": False,
            })
            fixture["returned"] = plain(value)
            fixture["exception_caught"] = False
        except Exception as exc:
            fixture["exception_caught"] = True
            fixture["exception_type"] = type(exc).__name__
            fixture["message"] = str(exc)
        error_message = await by_name["read_product_material"].ainvoke({
            "type": "tool_call", "id": "k24-wrong-hash",
            "name": "read_product_material", "args": {
                "material_id": "synthetic-manual", "revision": 1,
                "source_sha256": "0" * 64, "section_ids": ["section_rules"],
                "full_document": False,
            },
        })
        fixture["tool_call_response"] = plain(error_message)
        fixture["mcp_error_preserved_in_tool_message"] = getattr(error_message, "status", None) == "error"
        result["fixture_wrong_hash"] = fixture
    result["isolated_data_files"] = sorted(str(path.relative_to(HERE)) for path in (HERE / "empty-data").rglob("*") if path.is_file()) if (HERE / "empty-data").exists() else []
    result["sqlite_or_db_created"] = any(Path(path).suffix in {".db", ".sqlite", ".sqlite3"} for path in result["isolated_data_files"])
    (HERE / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"record": str(HERE / "result.json"), "tool_count": result["real_server"]["tool_count"],
                      "fixture_exception_caught": result["fixture_wrong_hash"]["exception_caught"],
                      "mcp_error_preserved_in_tool_message": result["fixture_wrong_hash"]["mcp_error_preserved_in_tool_message"],
                      "sqlite_or_db_created": result["sqlite_or_db_created"]}, ensure_ascii=False))


if __name__ == "__main__":
    asyncio.run(main())
