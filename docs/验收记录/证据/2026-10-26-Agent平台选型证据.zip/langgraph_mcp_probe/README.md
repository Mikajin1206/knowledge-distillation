# LangGraph 侧单知识 MCP 只读兼容探针（2026-10-26）

执行环境为父代理创建的隔离 `langgraph-venv`（LangGraph 1.2.17 / LangChain 1.4.7）。仅在本目录记录脚本、结果、子进程 stderr；未改原环境和本项目服务代码，未调用模型、真实 RAG 搜索、上传、发布或知识写入。

命令（仓库根执行）：

```sh
tmp/platform-selection-20261026/langgraph-venv/bin/python tmp/platform-selection-20261026/langgraph_mcp_probe/probe.py
```

## 实测结果

- 真实 `ckp.mcp_server` 以 stdio 子进程连接，`CKP_DATA`、`CKP_OUTPUT` 指向本目录隔离路径。`MCPAdapter` 发现 38 个工具。
- `distill_stages`：`server_version=1.5.6`、`parser_version=ckp-office-inspector-v0.4`、`image_renderer_version=ckp-emf-lo-primary-frame-guard-bitmap-fallback-v8`；仅预检信息读取，没有启动蒸馏任务。
- `product_material_list`：空库 `materials=[]`、`count=0`、`sandbox=true`；隔离数据目录没有生成文件和数据库。
- 已记录 `distill_stages`、`product_material_list`、`read_product_material` JSON schema。资料读取要求 `material_id`、整数 `revision`、`source_sha256`；可选 `section_ids`、`full_document` 保留。
- 同一适配器连接合成 fixture，传入错误原件哈希：服务拒绝；按 ToolCall 调用返回 `ToolMessage.status=error` 并保留 `tool_call_id=k24-wrong-hash`，未返回知识正文。
- 直接 `.ainvoke(args)` 默认不会向调用者抛异常，而返回错误文本内容块。这是适配器 `handle_tool_error` 的行为。应用不能以“未抛异常”判定成功；必须保留 ToolMessage 状态或做显式错误归一化。服务对意外异常给出通用错误文本，具体 hash mismatch 在隔离 stderr 中可见。
- `langchain.mcp` 导入产生官方 BetaWarning。

## 证据边界

这只证明已安装版本与本地单知识 MCP 的工具发现、JSON schema、预检、空库只读调用和合成错误传递相容。未验证真实 RAG、生产文件服务、HTTP 传输、企微、逐用户授权、模型工具选择、DeepSeek reasoning 字段往返或真实客户业务输出。

原始记录见 `result.json`，调用日志见 `fixture/mcp_calls.jsonl`。源码行为依据隔离环境 `langchain/mcp/tools.py` 的 `_MCPToolExecutionError`、`_handle_mcp_tool_error`、`_convert_call_tool_result`。
