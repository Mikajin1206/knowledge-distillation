"""Read-only native AgentScope client compatibility with the actual MCP code, empty data root."""
import asyncio
import json
import os
from pathlib import Path
from mcp import ClientSession
from agentscope.mcp import MCPClient, StdioMCPConfig

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
DATA = HERE / 'real-mcp-empty'
OUTPUT = HERE / 'output'

async def main():
    assert not DATA.exists(), 'Use a fresh isolated empty data path'
    captured = {}
    original_initialize = ClientSession.initialize
    async def capture_initialize(session):
        result = await original_initialize(session)
        captured.update(result.model_dump(mode='json'))
        return result
    ClientSession.initialize = capture_initialize
    client = MCPClient(name='real_knowledge', is_stateful=True,
        mcp_config=StdioMCPConfig(command=str(ROOT / '.venv/bin/python'),
            args=['-m','ckp.mcp_server'], cwd=str(ROOT),
            env={**os.environ,'PYTHONPATH':str(ROOT/'src'),'CKP_DATA':str(DATA),'CKP_OUTPUT':str(OUTPUT)}))
    await client.connect()
    try:
        raw = await client.list_raw_tools()
        wrapped = await client.list_tools()
        (HERE/'real_mcp_tool_schemas.json').write_text(json.dumps([t.model_dump(mode='json') for t in raw],ensure_ascii=False,indent=2))
        results = {}
        for name in ['distill_stages','product_material_list']:
            tool = await client.get_tool(name)
            response = await tool.call()
            results[name] = response.model_dump(mode='json')
        info = {
            'agentscope_version':'2.0.10','synthetic_empty_data_root':str(DATA),
            'server_info':captured.get('serverInfo'), 'protocol_version':captured.get('protocolVersion'),
            'raw_tool_count':len(raw),'wrapped_tool_count':len(wrapped),
            'calls':['distill_stages','product_material_list'],'results':results,
            'data_directory_created':DATA.exists(),'output_directory_created':OUTPUT.exists(),
            'database_files': [str(p.relative_to(HERE)) for p in DATA.rglob('*') if p.is_file()] if DATA.exists() else [],
            'model_requests':0,'scope':'native MCP protocol/schema + two read-only tools against isolated empty data; no real RAG access',
        }
        assert len(raw) == len(wrapped) == 38
        assert captured['serverInfo']['version'] == '1.5.6'
        listed=json.loads(''.join(x['text'] for x in results['product_material_list']['content'] if x['type']=='text'))
        assert listed['count']==0 and listed['materials']==[]
        assert not DATA.exists(), 'Read-only empty-corpus calls created data directory'
        assert not OUTPUT.exists(), 'Read-only calls created output directory'
        (HERE/'real_mcp_readonly_result.json').write_text(json.dumps(info,ensure_ascii=False,indent=2))
        print(json.dumps({'ok':True,'server_info':info['server_info'],'tools':len(raw),
                          'empty_product_material_count':0,'data_directory_created':False,'model_requests':0},ensure_ascii=False))
    finally:
        await client.close()
        ClientSession.initialize = original_initialize

if __name__=='__main__':
    asyncio.run(main())
