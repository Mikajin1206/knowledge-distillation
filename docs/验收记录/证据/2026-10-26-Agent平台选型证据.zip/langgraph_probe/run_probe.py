# -*- coding: utf-8 -*-
"""K24 compatibility probe; synthetic data and local artifacts only."""
import asyncio,json,os,sqlite3,sys
from pathlib import Path
from typing import TypedDict
from dotenv import dotenv_values
from openai import AsyncOpenAI
from langgraph.graph import StateGraph,START,END
from langgraph.types import interrupt,Command
from langgraph.checkpoint.sqlite import SqliteSaver
from langchain.mcp import MCPAdapter
from fastmcp.client.transports import StdioTransport
ROOT=Path(__file__).resolve().parents[3]
RUN=Path(__file__).resolve().parent
FIXTURE=RUN.parent/'fixture_mcp.py'
# parents[3] points at repository: .../tmp/platform-selection-20261026/langgraph_probe/run_probe.py
CONFIG=dotenv_values(ROOT/'.env')
class State(TypedDict,total=False):
    customer:str
    research:str
    evidence:list
    requirement:str
    approved:bool
    proposal:str
    operation_id:str

def record(kind,data):
    with (RUN/'events.jsonl').open('a') as f:f.write(json.dumps({'kind':kind,**data},ensure_ascii=False)+'\n')
def text_content(value):
    if isinstance(value,str):return value
    if isinstance(value,list):return '\n'.join(x.get('text','') if isinstance(x,dict) else str(x) for x in value)
    return json.dumps(value,ensure_ascii=False,default=str)
def client():
    return AsyncOpenAI(api_key=CONFIG['LLM_API_KEY'],base_url=CONFIG['LLM_BASE_URL'],timeout=50,max_retries=0)
async def completion(messages,tools=None):
    args={'model':'deepseek-flash','messages':messages,'max_tokens':1000,'extra_body':{'thinking':{'type':'disabled'}}}
    if tools is not None:args.update(tools=tools,tool_choice='auto',parallel_tool_calls=False)
    async with client() as api:result=await api.chat.completions.create(**args)
    record('model_call',{'model':result.model,'usage':result.usage.model_dump() if result.usage else None,'thinking':'disabled'})
    return result.choices[0].message
async def research_async():
    transport=StdioTransport(command=str(ROOT/'.venv/bin/python'),args=[str(FIXTURE)],env={'K24_RUN_DIR':str(RUN)})
    messages=[{'role':'system','content':'你在做合成资料的框架兼容验证。所有客户和产品都是SYNTHETIC，不是真实公司能力。必须先调用search_product_materials，再按命中精确material_id/revision/source_sha256调用read_product_material，只补读section_rules，full_document=false。得到两个结果后写一段不超过200字的需求草稿，保留来源修订及限制。不要反复调用，不要编造接口或量化收益。'}, {'role':'user','content':'合成客户采购靠群消息通知订单变更，希望供应商确认状态可见。检索手册并形成需求草稿。'}]
    evidence=[]
    async with MCPAdapter(transport) as adapter:
        native=await adapter.list_tools()
        byname={t.name:t for t in native}
        schemas=[{'type':'function','function':{'name':t.name,'description':t.description,'parameters':t.args_schema if isinstance(t.args_schema,dict) else t.args_schema.model_json_schema()}} for t in native]
        for step in range(4):
            msg=await completion(messages,schemas)
            messages.append(msg.model_dump(exclude_none=True))
            if not msg.tool_calls:
                assert {'search_product_materials','read_product_material'} <= {e['tool'] for e in evidence},'both retrieval tools required'
                return {'research':msg.content,'evidence':evidence,'requirement':'订单变更供应商确认状态可见','operation_id':'synthetic-task:proposal:1'}
            for call in msg.tool_calls:
                args=json.loads(call.function.arguments)
                result=await byname[call.function.name].ainvoke(args)
                content=text_content(result)
                evidence.append({'tool':call.function.name,'args':args,'result':content})
                messages.append({'role':'tool','tool_call_id':call.id,'content':content})
        raise RuntimeError('bounded model loop did not complete')
def research(state):return asyncio.run(research_async())
def confirm(state):
    answer=interrupt({'type':'requirements_review','requirement':state['requirement'],'research':state['research'],'revision':1})
    assert answer['decision']=='accept'
    return {'approved':True,'requirement':answer['requirement']}
def proposal(state):
    assert state['approved']
    async def generate():
        msg=await completion([{'role':'system','content':'仅根据给定合成证据为合成客户写一个可审阅方案。写业务角色/处理步骤/例外与边界/下一次确认问题，保留合成标记及来源修订；无实际接口和量化收益证据不要承诺。最多400个汉字。'}, {'role':'user','content':json.dumps({'requirement':state['requirement'],'evidence':state['evidence']},ensure_ascii=False)}])
        return msg.content
    return {'proposal':asyncio.run(generate())}
def persist(state):
    with sqlite3.connect(RUN/'business.sqlite') as db:
        db.execute('CREATE TABLE IF NOT EXISTS artifacts(operation_id TEXT PRIMARY KEY,body TEXT)')
        db.execute('INSERT OR IGNORE INTO artifacts VALUES (?,?)',(state['operation_id'],state['proposal']))
        count=db.execute('SELECT count(*) FROM artifacts').fetchone()[0]
    (RUN/'proposal.md').write_text(state['proposal'])
    record('persist',{'count':count,'operation_id':state['operation_id']})
    return {}
def graph(saver):
    builder=StateGraph(State)
    for name,fn in [('research',research),('confirm',confirm),('proposal',proposal),('persist',persist)]:builder.add_node(name,fn)
    builder.add_edge(START,'research');builder.add_edge('research','confirm');builder.add_edge('confirm','proposal');builder.add_edge('proposal','persist');builder.add_edge('persist',END)
    return builder.compile(checkpointer=saver)
def counts():
    calls=(RUN/'mcp_calls.jsonl').read_text().splitlines() if (RUN/'mcp_calls.jsonl').exists() else []
    models=[x for x in (RUN/'events.jsonl').read_text().splitlines() if json.loads(x)['kind']=='model_call'] if (RUN/'events.jsonl').exists() else []
    return {'mcp':len(calls),'model':len(models)}
def main():
    config={'configurable':{'thread_id':'synthetic-customer/task-1'}}
    with SqliteSaver.from_conn_string(str(RUN/'checkpoints.sqlite')) as saver:
        app=graph(saver)
        if sys.argv[1]=='start':
            result=app.invoke({'customer':'SYNTHETIC'},config,durability='sync')
            assert result.get('__interrupt__')
            snapshot=app.get_state(config)
            assert snapshot.next==('confirm',)
            (RUN/'start.json').write_text(json.dumps({'paused':True,'next':snapshot.next,'counts':counts(),'pid':os.getpid()},ensure_ascii=False,indent=2))
            print('PASS start: search/read via actual DeepSeek tool calls; SQLite checkpoint waiting at confirmation')
        elif sys.argv[1]=='resume':
            before=counts(); result=app.invoke(Command(resume={'decision':'accept','requirement':'订单变更供应商确认状态可见；接口能力需进一步核实'}),config,durability='sync')
            after=counts();assert before['mcp']==after['mcp'],'research must not replay after process restart'
            assert result['approved'] and result['proposal'] and app.get_state(config).next==()
            assert app.get_state({'configurable':{'thread_id':'another-task'}}).values=={}
            (RUN/'resume.json').write_text(json.dumps({'completed':True,'counts_before':before,'counts_after':after,'isolated_thread':True,'pid':os.getpid()},ensure_ascii=False,indent=2))
            print('PASS resume: new process resumed persisted confirmation; no repeated retrieval; distinct task state isolated')
        elif sys.argv[1]=='duplicate':
            before=counts();app.invoke(Command(resume={'decision':'accept','requirement':'duplicate'}),config,durability='sync');after=counts()
            assert before==after,'duplicate completed resume must not trigger model or tools'
            with sqlite3.connect(RUN/'business.sqlite') as db:count=db.execute('SELECT count(*) FROM artifacts').fetchone()[0]
            assert count==1
            (RUN/'duplicate.json').write_text(json.dumps({'duplicate_no_model_or_tools':True,'artifact_count':count,'pid':os.getpid()},indent=2))
            print('PASS duplicate: no extra model/tools; one idempotent local business artifact')
if __name__=='__main__':
    try:main()
    except Exception as e:
        record('failure',{'type':type(e).__name__,'message':str(e)[:350]})
        print('FAIL',type(e).__name__,str(e)[:350]);sys.exit(1)
