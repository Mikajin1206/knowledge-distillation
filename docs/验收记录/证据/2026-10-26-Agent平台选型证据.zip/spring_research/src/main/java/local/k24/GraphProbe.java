package local.k24;

import com.alibaba.cloud.ai.graph.CompileConfig;
import com.alibaba.cloud.ai.graph.KeyStrategyFactoryBuilder;
import com.alibaba.cloud.ai.graph.RunnableConfig;
import com.alibaba.cloud.ai.graph.StateGraph;
import com.alibaba.cloud.ai.graph.checkpoint.config.SaverConfig;
import com.alibaba.cloud.ai.graph.checkpoint.savers.file.FileSystemSaver;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Map;
import static com.alibaba.cloud.ai.graph.StateGraph.START;
import static com.alibaba.cloud.ai.graph.StateGraph.END;
import static com.alibaba.cloud.ai.graph.action.AsyncNodeAction.node_async;

/** Isolated graph baseline, with opt-in synthetic model/MCP integration. */
public class GraphProbe {
    private static final ObjectMapper JSON = new ObjectMapper();

    private static void event(Path dir, String mode, String value) throws Exception {
        Files.writeString(dir.resolve("events.log"), "mode=" + mode + " pid=" + ProcessHandle.current().pid()
            + " event=" + value + "\n", StandardOpenOption.CREATE, StandardOpenOption.APPEND);
    }

    public static void main(String[] args) throws Exception {
        try {
            run(args);
        } finally {
            // Standalone probe lifecycle only; service worker lifecycle belongs to K17.
            reactor.core.scheduler.Schedulers.shutdownNow();
        }
    }

    private static void run(String[] args) throws Exception {
        if (args.length != 2) throw new IllegalArgumentException("expected mode and isolated run directory");
        String mode = args[0];
        if (!mode.equals("start") && !mode.equals("resume")) {
            throw new IllegalArgumentException("mode must be start or resume");
        }
        String rootValue = System.getenv("K24_ROOT");
        if (rootValue == null || rootValue.isBlank()) throw new IllegalArgumentException("K24_ROOT is required");
        Path root = Path.of(rootValue).toRealPath();
        Path dir = isolatedRunDirectory(root, args[1]);
        boolean realModel = "true".equalsIgnoreCase(System.getenv("K24_REAL_MODEL"));
        event(dir, mode, "process_start");
        var strategies = new KeyStrategyFactoryBuilder()
            .addStrategy("customer").addStrategy("profile").addStrategy("approved")
            .addStrategy("evidence").addStrategy("requirements").addStrategy("solution").addStrategy("artifact_id").build();
        StateGraph graph = new StateGraph(strategies)
            .addNode("profile", node_async(state -> {
                event(dir, mode, "profile");
                if (realModel) {
                    var research = ModelMcpProbe.run(root, dir.resolve("research"));
                    if (!Boolean.TRUE.equals(research.get("ok"))) {
                        throw new IllegalStateException("model/MCP research failed its checks; see isolated research record");
                    }
                    Object value = research.get("text");
                    if (!(value instanceof String text) || text.isBlank()) {
                        throw new IllegalStateException("model/MCP research returned empty text");
                    }
                    return Map.of("profile", text, "evidence", JSON.writeValueAsString(research.get("mcp_trace")));
                }
                return Map.of("profile", "synthetic: customer process unknown; no invented facts", "evidence", "synthetic deterministic baseline");
            }))
            .addNode("review", node_async(state -> {
                event(dir, mode, "review");
                if (!Boolean.TRUE.equals(state.value("approved").orElse(false))) {
                    throw new IllegalStateException("sales confirmation required");
                }
                return Map.of("requirements", "synthetic: versioned order changes and supplier confirmation");
            }))
            .addNode("solution", node_async(state -> {
                event(dir, mode, "solution");
                Path artifact = dir.resolve("artifact-k24-op-1.txt");
                if (Files.exists(artifact)) {
                    event(dir, mode, "artifact_reused");
                    return Map.of("solution", Files.readString(artifact), "artifact_id", "k24-op-1");
                }
                String text = "synthetic only: retrieve exact manual sections, plan workflow, preserve interface gaps";
                if (realModel) {
                    String profile = (String) state.value("profile").orElseThrow();
                    String evidence = (String) state.value("evidence").orElseThrow();
                    text = ModelMcpProbe.generateProposal(dir.resolve("proposal"), profile, evidence);
                    if (text == null || text.isBlank()) throw new IllegalStateException("model proposal returned empty text");
                }
                try {
                    Files.writeString(artifact, text, StandardOpenOption.CREATE_NEW);
                    event(dir, mode, "artifact_created");
                } catch (FileAlreadyExistsException duplicate) {
                    text = Files.readString(artifact);
                    event(dir, mode, "artifact_reused");
                }
                return Map.of("solution", text, "artifact_id", "k24-op-1");
            }))
            .addEdge(START, "profile").addEdge("profile", "review")
            .addEdge("review", "solution").addEdge("solution", END);
        var saver = FileSystemSaver.builder().targetFolder(dir.resolve("checkpoints"))
            .stateSerializer(graph.getStateSerializer()).build();
        var app = graph.compile(CompileConfig.builder()
            .saverConfig(SaverConfig.builder().register(saver).build())
            .interruptBefore("review").build());
        var config = RunnableConfig.builder().threadId("k24-thread-1").build();
        if (mode.equals("start")) {
            app.stream(Map.of("customer", "synthetic-customer"), config).blockLast();
        } else if (mode.equals("resume")) {
            var updated = app.updateState(config, Map.of("approved", true), null);
            app.stream(Map.of(), updated.withResume()).blockLast();
        }
        String snapshot = app.getState(config).state().data().toString();
        Files.writeString(dir.resolve(mode + "-state.txt"), snapshot);
        System.out.println(snapshot);
        event(dir, mode, "process_completed");
    }

    private static Path isolatedRunDirectory(Path root, String value) throws Exception {
        Path tmp = root.resolve("tmp").toRealPath();
        Path requested = Path.of(value).toAbsolutePath().normalize();
        if (!requested.startsWith(tmp) || requested.equals(tmp)) {
            throw new IllegalArgumentException("run directory must be a child of K24_ROOT/tmp");
        }
        Path existing = requested;
        while (!Files.exists(existing)) existing = existing.getParent();
        if (!existing.toRealPath().startsWith(tmp)) {
            throw new IllegalArgumentException("run directory resolves outside K24_ROOT/tmp");
        }
        Files.createDirectories(requested);
        Path resolved = requested.toRealPath();
        if (!resolved.startsWith(tmp) || resolved.equals(tmp)) {
            throw new IllegalArgumentException("run directory resolves outside K24_ROOT/tmp");
        }
        return resolved;
    }
}
