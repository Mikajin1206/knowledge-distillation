# Spring AI Alibaba 最小兼容探针草案（2026-10-26）

当前状态：官方文档及固定 tag 源码已核查；本目录 Java 代码尚未编译运行。父代理负责准备隔离 Java/Maven 环境与实测。没有模型调用、生产 PostgreSQL 或真实 RAG 搜索。

## 固定版本与依赖

- Spring AI Alibaba GitHub Latest 稳定版 `v1.1.2.2`（2026-03-10）；`v2.0.0-M1.1` 是预发布。
- `v1.1.2.2` 根 POM：Java 17、Spring Boot 3.5.8、Spring AI 1.1.2、Extensions 1.1.2.2。
- 无模型 Graph 最小坐标：`com.alibaba.cloud.ai:spring-ai-alibaba-graph-core:1.1.2.2`。
- POM 已加入 Agent 层 `com.alibaba.cloud.ai:spring-ai-alibaba-agent-framework:1.1.2.2`、模型适配 `org.springframework.ai:spring-ai-deepseek:1.1.2`，当前 Graph baseline 仍无模型调用。
- POM 已加入 `org.springframework.ai:spring-ai-mcp:1.1.2`。Spring AI v1.1.2 官方父 POM 将 MCP SDK 固定为 `0.17.0`，不用当前网页的滚动版本替代。
- 官方仓库为 Apache 2.0；框架本地运行与模型供应商账号、API 付费分别处理。

## Graph 草案

`src/main/java/local/k24/GraphProbe.java`：`profile -> review -> solution`，编译配置 `.interruptBefore("review")`；`FileSystemSaver` 写本地目录；第二 Java 进程构造同一图和 thread，`updateState` 写确认，`.withResume()` 后恢复。业务产物固定操作 ID + `CREATE_NEW`，模拟业务幂等；checkpoint 本身不提供跨业务库的恰好一次提交。

`profile` 预留 `K24_REAL_MODEL=true` 集成位置。独立 `ModelMcpProbe` 接入前，该分支显式抛出 integration pending；不会把 fixture 输出标成真实模型结果。模型默认分支保持确定性，`solution` 当前仍是 fixture。

父代理在本目录编译，然后以两个独立命令/进程执行：

```sh
mvn compile exec:java -Dexec.mainClass=local.k24.GraphProbe -Dexec.args='start /absolute/path/to/spring_research/run'
mvn exec:java -Dexec.mainClass=local.k24.GraphProbe -Dexec.args='resume /absolute/path/to/spring_research/run'
```

预期第一进程只写 `profile` 事件，没有业务产物；第二进程执行 `review`、`solution`，产物仅一次。再次从同 thread 发起普通 start/确认流程可检验业务重复请求时产物复用。上述是验收预期，不能写为已通过。

固定 tag 的 `GraphRunnerContext` 会在 metadata 有 HUMAN_FEEDBACK 或有 checkpoint ID 时走恢复分支；单纯提供 thread ID + 空 Map 会走 START。故代码明确 `.withResume()`。`FileSystemSaver` 从文件反序列化 checkpoint，插入时同步序列化整个 checkpoint 列表；这能做双进程顺序验证，不能推出多工作进程并发更新能力。

## MCP 草案

`src/main/java/local/k24/McpProbe.java` 使用官方 SDK 0.17 的 `ServerParameters` + 两参数 `StdioClientTransport(..., McpJsonMapper.createDefault())`，连接本项目 `.venv/bin/python -m ckp.mcp_server`；隔离 `PYTHONPATH`、`CKP_DATA`、`CKP_OUTPUT`。只调用工具发现、`distill_stages`、`product_material_list`，记录 schema 与状态。Java 稳定版 `SyncMcpToolCallback` 遇到 `isError=true` 会抛 `ToolExecutionException`；业务层仍需解析知识服务自身返回的业务错误结构。

## 官方来源与源码入口

- Releases：https://github.com/alibaba/spring-ai-alibaba/releases
- 固定 tag 根 POM：https://github.com/alibaba/spring-ai-alibaba/blob/v1.1.2.2/pom.xml
- Graph POM：https://github.com/alibaba/spring-ai-alibaba/blob/v1.1.2.2/spring-ai-alibaba-graph-core/pom.xml
- FileSystemSaver：https://github.com/alibaba/spring-ai-alibaba/blob/v1.1.2.2/spring-ai-alibaba-graph-core/src/main/java/com/alibaba/cloud/ai/graph/checkpoint/savers/file/FileSystemSaver.java
- 官方文件 saver 用例：https://github.com/alibaba/spring-ai-alibaba/blob/v1.1.2.2/spring-ai-alibaba-graph-core/src/test/java/com/alibaba/cloud/ai/graph/StateGraphFileSystemSaverTest.java
- Resume 判断：https://github.com/alibaba/spring-ai-alibaba/blob/v1.1.2.2/spring-ai-alibaba-graph-core/src/main/java/com/alibaba/cloud/ai/graph/GraphRunnerContext.java
- withResume：https://github.com/alibaba/spring-ai-alibaba/blob/v1.1.2.2/spring-ai-alibaba-graph-core/src/main/java/com/alibaba/cloud/ai/graph/RunnableConfig.java
- updateState：https://github.com/alibaba/spring-ai-alibaba/blob/v1.1.2.2/spring-ai-alibaba-graph-core/src/main/java/com/alibaba/cloud/ai/graph/CompiledGraph.java
- Spring AI 固定 POM：https://github.com/spring-projects/spring-ai/blob/v1.1.2/pom.xml
- Spring AI MCP POM：https://github.com/spring-projects/spring-ai/blob/v1.1.2/mcp/common/pom.xml
- MCP 工具错误处理：https://github.com/spring-projects/spring-ai/blob/v1.1.2/mcp/common/src/main/java/org/springframework/ai/mcp/SyncMcpToolCallback.java
- SDK 固定 stdio：https://github.com/modelcontextprotocol/java-sdk/blob/v0.17.0/mcp-core/src/main/java/io/modelcontextprotocol/client/transport/StdioClientTransport.java
- SDK 固定进程参数：https://github.com/modelcontextprotocol/java-sdk/blob/v0.17.0/mcp-core/src/main/java/io/modelcontextprotocol/client/transport/ServerParameters.java
- Spring 官方 MCP 说明（滚动 1.1 文档，须与固定 tag 核对）：https://docs.spring.io/spring-ai/reference/1.1/api/mcp/mcp-client-boot-starter-docs.html
- java2ai 版本说明目前仍将 1.1.2.0 标为推荐，与 GitHub 最新 patch 有差异：https://java2ai.com/docs/versions/

本目录同名源码文件来自官方 `v1.1.2.2` tag，只作研究资料，不是本项目实现。
