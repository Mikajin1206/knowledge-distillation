# K24 AgentScope 2.0.10 隔离兼容验证

日期：2026-10-26。材料、客户、需求、确认决策与本地事务均为 synthetic。模型真实调用官方 `https://api.deepseek.com` 的 `deepseek-flash`，非 thinking。凭据从项目 `.env` 读取，未输出密钥或请求头。

## 实际结果

- AgentScope 安装版本：2.0.10；运行于父任务创建的 Python 3.12 隔离环境。
- 第一进程 PID 54711：原生 Agent + Toolkit(mcps=[MCPClient]) 完成一次 `search_product_materials`，再根据返回的准确 material_id/revision/source_sha256 读取 `section_rules`；`full_document=false`。
- 随后调用独立 FunctionTool `confirm_sales_requirements`，使用默认 ASK，产生 `RequireUserConfirmEvent`；保存 AgentState，进程正常退出。确认工具在该进程未执行。
- 第二进程 PID 54804：从 checkpoint JSON 重建 AgentState、Agent、Toolkit 和 MCP 连接；相同 session_id，送入关联原 tool_call 的 `UserConfirmResultEvent(confirmed=True)` 后执行确认工具，再生成简短方案及推进建议。
- MCP 轨迹仅有 search/read 两次，没有恢复后重复检索或全文读取。
- 确认工具在本目录保存一份固定 transaction_id 的 synthetic 记录。直接重复调用该本地函数返回 replayed=true，writes=1。此项仅证明 fixture 本地事务实现的幂等性。
- 全过程 4 次真实模型请求，脚本限制最多 6 次；模型自身及底层 OpenAI SDK 重试均设为 0。每次 max_tokens=1200。

| 阶段 | 请求数 | input_tokens | output_tokens | cache_input_tokens |
|---|---:|---:|---:|---:|
| prepare | 3 | 3656 | 501 | 2304 |
| resume | 1 | 2058 | 387 | 1664 |
| 合计 | 4 | 5714 | 888 | 3968 |

input_tokens 含缓存输入；cache_input_tokens 是其子集，不能额外累加。总输入加输出为 6602 tokens。

## 证据文件

- `probe.py`：实际脚本。凭据未写入脚本。
- `prepare_result.json`、`resume_result.json`：进程 PID、版本、停驻与恢复结果。
- `mcp_calls.jsonl`：两个知识工具的真实调用及定向读取参数。
- `checkpoint.json`、`pending_confirmation.json`：停驻状态和关联确认事件。
- `prepare_events.jsonl`、`resume_events.jsonl`：原始 Agent 事件；`prepare_usage.json`、`resume_usage.json` 为 API usage。
- `api_budget.json`：累计 4 次请求。
- `transaction.json`：一次本地确认产物；`proposal.md`、`final_message.json`：恢复后的模型产物。
- 两阶段 stdout/stderr 日志均在本目录。

## 验证范围与局限

本次证明 Agent 消息状态和停驻工具确认可以跨正常进程退出后恢复，保留原会话、知识证据与工具调用关联。未验证 SOP 全业务流程恢复、运行中强制崩溃、数据库事务恢复或并发重复回调。

确认由脚本输入 synthetic `confirmed=True`，不是销售人工验收。未接入企业微信租户，未读取真实 Word 或现有 RAG 库，未验证生产知识权限、检索效果及正式详细售前方案质量。

人工阅览发现：产物正确保留接口未验证、交期和量化收益未知，也给出沟通对象、问题和应确认结果；但“变更内容推送给对应供应商”比 fixture 明示能力多一步，“未确认清单”是设计推导。正式方案应把这类内容标为待验证设计建议，不能作为已证实标准产品能力。本次不据此宣称售前方案业务验收完成。

## 执行命令

从项目根目录分别运行两条命令，实际为两个独立进程：

```sh
tmp/platform-selection-20261026/agentscope-venv/bin/python tmp/platform-selection-20261026/agentscope_probe/probe.py prepare
tmp/platform-selection-20261026/agentscope-venv/bin/python tmp/platform-selection-20261026/agentscope_probe/probe.py resume
```

现有结果需要保留；重新执行 prepare 应使用独立目录，避免与已完成事务/调用轨迹混用。

## 原知识 MCP 只读兼容补充

另以原生 MCPClient 通过根 `.venv/bin/python -m ckp.mcp_server` 启动本仓库真实 MCP 代码，`PYTHONPATH` 指向根 `src/`，`CKP_DATA` 和 `CKP_OUTPUT` 指向本目录下独立、原本不存在的路径。未加载真实知识数据。

- 握手 `serverInfo={name: Knowledge Distillation, version: 1.5.6}`；原始工具和 AgentScope 包装工具均为 38 个。
- 仅调用 `distill_stages` 与 `product_material_list`，产品资料列表 count=0、materials=[]。
- 数据目录与输出目录均未创建，未生成数据库；未搜索、上传、发布或调用模型。
- `distill_stages` 返回的 `server_info` 保留当前解析器与渲染器版本，详见原始结果。
- 脚本：`real_mcp_readonly.py`；结果：`real_mcp_readonly_result.json`；全部工具 schema：`real_mcp_tool_schemas.json`；日志：`real_mcp_stdout.log`、`real_mcp_stderr.log`。

此项只证明真实服务的 STDIO 协议、工具 schema 包装和两个空库只读调用兼容，不证明实际产品资料搜索效果或生产接入。
