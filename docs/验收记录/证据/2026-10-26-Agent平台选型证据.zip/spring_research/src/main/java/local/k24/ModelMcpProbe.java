package local.k24;

import com.alibaba.cloud.ai.graph.RunnableConfig;
import com.alibaba.cloud.ai.graph.agent.ReactAgent;
import com.alibaba.cloud.ai.graph.checkpoint.savers.MemorySaver;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.modelcontextprotocol.client.McpClient;
import io.modelcontextprotocol.client.transport.ServerParameters;
import io.modelcontextprotocol.client.transport.StdioClientTransport;
import io.modelcontextprotocol.json.McpJsonMapper;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import org.springframework.ai.chat.metadata.Usage;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.ai.chat.messages.ToolResponseMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.prompt.ChatOptions;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.deepseek.DeepSeekChatModel;
import org.springframework.ai.deepseek.DeepSeekChatOptions;
import org.springframework.ai.deepseek.api.DeepSeekApi;
import org.springframework.ai.mcp.McpToolNamePrefixGenerator;
import org.springframework.ai.mcp.SyncMcpToolCallbackProvider;
import org.springframework.retry.support.RetryTemplate;

/**
 * Isolated real-model draft for SAA 1.1.2.2 / Spring AI 1.1.2.
 * No real knowledge data or credentials are written. The MCP process is synthetic.
 * Native DeepSeek 1.1.2 has no explicit thinking switch; actual behavior is unverified.
 */
public class ModelMcpProbe {
    private static final ObjectMapper JSON = new ObjectMapper();
    private static final String INSTRUCTION = """
        这是 synthetic 合成兼容验证，客户与材料均为合成数据。
        客户问题：订单变更后供应商确认不及时，采购不知道谁未确认。
        必须依次执行且每步只调用一次：
        1. search_product_materials 查询订单变更及供应商确认。
        2. 使用搜索结果中的准确 material_id、revision、source_sha256 调用 read_product_material；
           section_ids 必须为 [\"section_rules\"]，full_document 必须为 false，禁止全文读取。
        3. 补读成功后，输出不超过200个中文字的 synthetic 需求分析。
           写明客户问题、手册证实的三项能力、接口未验证且交期与量化收益未知，
           以及下一轮与采购和信息部门要确认的问题。不要声称已证实“推送”等手册未写明能力。
           结尾保留 synthetic-manual/revision=1/section_rules 引用；随后结束，不再调用工具。
        不要跳步，不要编造 hash，不要重复检索。当前只生成需求分析，不执行销售确认或写业务库。
        """;

    /** Tracks each synchronous underlying model response, with a strict request budget. */
    private static final class MeteredModel implements ChatModel {
        private final DeepSeekChatModel delegate;
        private final AtomicInteger requests = new AtomicInteger();
        private final List<Map<String, Object>> usage = new ArrayList<>();
        private final int maxCalls;
        private Throwable failure;

        MeteredModel(DeepSeekChatModel delegate) { this(delegate, 4); }
        MeteredModel(DeepSeekChatModel delegate, int maxCalls) {
            this.delegate = delegate;
            this.maxCalls = maxCalls;
        }

        @Override public ChatOptions getDefaultOptions() { return delegate.getDefaultOptions(); }

        @Override public ChatResponse call(Prompt prompt) {
            if (requests.get() >= maxCalls) {
                failure = new IllegalStateException("Maximum model calls exceeded: " + maxCalls);
                throw (IllegalStateException) failure;
            }
            requests.incrementAndGet();
            try {
                ChatResponse response = delegate.call(prompt);
                Usage value = response.getMetadata().getUsage();
                Map<String, Object> entry = new LinkedHashMap<>();
                entry.put("input_tokens", value.getPromptTokens());
                entry.put("output_tokens", value.getCompletionTokens());
                entry.put("total_tokens", value.getTotalTokens());
                entry.put("synthetic_tool_results_in_prompt", prompt.getInstructions().stream()
                    .filter(ToolResponseMessage.class::isInstance)
                    .map(m -> ((ToolResponseMessage) m).getResponses()).toList());
                usage.add(entry);
                return response;
            } catch (RuntimeException e) {
                failure = e;
                throw e;
            }
        }
    }

    /** Callable later from a Graph research node. Output files are confined to run. */
    public static Map<String, Object> run(Path root, Path run) throws Exception {
        root = root.toAbsolutePath();
        run = run.toAbsolutePath();
        Files.createDirectories(run);
        Path trace = run.resolve("mcp_calls.jsonl");
        if (Files.exists(trace)) throw new IllegalStateException("Use a fresh K24 run directory");
        String key = requireEnv("LLM_API_KEY");
        String modelName = requireEnv("LLM_MODEL_NAME");
        var metered = new MeteredModel(nativeModel());
        var params = ServerParameters.builder(root.resolve(".venv/bin/python").toString())
            .args(root.resolve("tmp/platform-selection-20261026/fixture_mcp.py").toString())
            .env(Map.of("K24_RUN_DIR", run.toString(), "PYTHONUNBUFFERED", "1")).build();
        var transport = new StdioClientTransport(params, McpJsonMapper.createDefault());
        var client = McpClient.sync(transport).requestTimeout(Duration.ofSeconds(20)).build();
        Map<String, Object> record = new LinkedHashMap<>();
        record.put("synthetic", true);
        record.put("framework", "spring-ai-alibaba-agent-framework:1.1.2.2");
        record.put("spring_ai", "1.1.2");
        record.put("model", modelName);
        record.put("native_deepseek_thinking_switch", "not available in 1.1.2; provider default used");
        record.put("max_output_tokens_per_request", 1000);
        record.put("retry_max_attempts", 1);
        try {
            record.put("mcp_initialize", client.initialize());
            var provider = SyncMcpToolCallbackProvider.builder().mcpClients(client)
                .toolNamePrefixGenerator(McpToolNamePrefixGenerator.noPrefix())
                .toolFilter((connection, tool) -> Set.of("search_product_materials", "read_product_material")
                    .contains(tool.name())).build();
            record.put("mcp_tool_names", java.util.Arrays.stream(provider.getToolCallbacks())
                .map(t -> t.getToolDefinition().name()).toList());
            var agent = ReactAgent.builder().name("k24_synthetic_research")
                .model(metered).instruction(INSTRUCTION).toolCallbackProviders(provider)
                .saver(new MemorySaver()).build();
            var config = RunnableConfig.builder().threadId("k24-synthetic-research")
                .addMetadata("_stream_", false).build();
            var answer = agent.call("请按指定流程检索并定向补读，然后形成简短合成需求分析。", config);
            String text = answer.getText();
            record.put("text", text);
            Files.writeString(run.resolve("requirements.md"), text == null ? "" : text);
            List<JsonNode> calls = new ArrayList<>();
            if (Files.exists(trace)) for (String line : Files.readAllLines(trace)) calls.add(JSON.readTree(line));
            record.put("mcp_trace", calls);
            boolean orderOk = calls.size() == 2
                && calls.get(0).path("tool").asText().equals("search_product_materials")
                && calls.get(1).path("tool").asText().equals("read_product_material")
                && calls.get(1).path("args").path("material_id").asText().equals("synthetic-manual")
                && calls.get(1).path("args").path("revision").asInt() == 1
                && calls.get(1).path("args").path("source_sha256").asText()
                    .equals("31c8978b9a07cf78af0a3bb38aae6629fd34d7ebd3dc464b5f153e9ad58b2658")
                && calls.get(1).path("args").path("section_ids").equals(JSON.readTree("[\"section_rules\"]"))
                && !calls.get(1).path("args").path("full_document").asBoolean(true);
            record.put("search_then_exact_targeted_read", orderOk);
            long chineseCharacters = text == null ? 0 : text.codePoints()
                .filter(c -> Character.UnicodeScript.of(c) == Character.UnicodeScript.HAN).count();
            record.put("output_chinese_characters", chineseCharacters);
            // The fixture itself rejects incorrect id/revision/hash, so two successful calls are evidence.
            record.put("ok", orderOk && metered.failure == null && text != null && text.contains("synthetic")
                && chineseCharacters <= 200);
            if (metered.failure != null) record.put("model_failure", safeFailure(metered.failure, key));
        } catch (Exception e) {
            record.put("ok", false);
            record.put("failure", safeFailure(e, key));
        } finally {
            record.put("model_requests", metered.requests.get());
            record.put("usage_by_request", metered.usage);
            record.put("untested", List.of("Explicit non-thinking control", "Real RAG corpus", "WeCom",
                "Human confirmation", "Cross-process graph recovery", "Formal proposal quality"));
            client.closeGracefully();
            JSON.writerWithDefaultPrettyPrinter().writeValue(run.resolve("model-mcp-result.json").toFile(), record);
        }
        return record;
    }

    /** One native DeepSeek call for the Graph's post-confirmation proposal node. */
    public static String generateProposal(Path run, String research, String evidence) throws Exception {
        run = run.toAbsolutePath();
        Files.createDirectories(run);
        String key = requireEnv("LLM_API_KEY");
        var model = new MeteredModel(nativeModel(), 1);
        Map<String, Object> record = new LinkedHashMap<>();
        record.put("synthetic", true);
        record.put("model", requireEnv("LLM_MODEL_NAME"));
        record.put("native_deepseek_thinking_switch", "not available in 1.1.2; provider default used");
        record.put("max_output_tokens_per_request", 1000);
        record.put("retry_max_attempts", 1);
        record.put("synthetic_research", research);
        record.put("synthetic_evidence", evidence);
        String text = null;
        try {
            var prompt = new Prompt(List.of(
                new SystemMessage("""
                    你正在进行 synthetic 合成售前平台验证。需求分析已经由合成销售确认。
                    仅根据给定 research 和 evidence 生成不超过300个中文字的简短方案及推进建议。
                    明确标记 synthetic，包含：客户问题；订单变更留版本、供应商在线确认、
                    采购查询待确认状态如何支撑业务；接口条件未验证，交期与量化收益未知；
                    下一轮与采购和信息部门的沟通问题及应确认结果；保留证据资料版本和分节引用。
                    不得新增证据未说明的“自动推送、催办、接口已打通”等标准能力。
                    可以提出待核实设计建议，但必须明确标注为待核实。不要调用工具。
                    """),
                new UserMessage("synthetic research:\n" + research + "\nsynthetic evidence:\n" + evidence)));
            var response = model.call(prompt);
            text = response.getResult().getOutput().getText();
            long chineseCharacters = text == null ? 0 : text.codePoints()
                .filter(c -> Character.UnicodeScript.of(c) == Character.UnicodeScript.HAN).count();
            record.put("text", text);
            record.put("output_chinese_characters", chineseCharacters);
            record.put("ok", text != null && text.contains("synthetic") && chineseCharacters <= 300);
            Files.writeString(run.resolve("proposal.md"), text == null ? "" : text);
            if (!Boolean.TRUE.equals(record.get("ok"))) {
                throw new IllegalStateException("Proposal missing synthetic label or exceeds 300 Chinese characters");
            }
        } catch (Exception e) {
            record.put("ok", false);
            record.put("failure", safeFailure(e, key));
            throw e;
        } finally {
            record.put("model_requests", model.requests.get());
            record.put("usage_by_request", model.usage);
            record.put("untested", List.of("Explicit non-thinking control", "Formal proposal business acceptance",
                "WeCom", "Real knowledge corpus"));
            JSON.writerWithDefaultPrettyPrinter().writeValue(run.resolve("proposal-result.json").toFile(), record);
        }
        return text;
    }

    private static DeepSeekChatModel nativeModel() {
        String baseUrl = requireEnv("LLM_BASE_URL");
        if (!baseUrl.replaceAll("/$", "").equals("https://api.deepseek.com")) {
            throw new IllegalArgumentException("Only the authorized official DeepSeek endpoint is allowed");
        }
        var api = DeepSeekApi.builder().baseUrl(baseUrl).apiKey(requireEnv("LLM_API_KEY")).build();
        var options = DeepSeekChatOptions.builder().model(requireEnv("LLM_MODEL_NAME")).maxTokens(1000)
            .internalToolExecutionEnabled(false).build();
        return DeepSeekChatModel.builder().deepSeekApi(api).defaultOptions(options)
            .retryTemplate(RetryTemplate.builder().maxAttempts(1).build()).build();
    }

    private static String requireEnv(String name) {
        String value = System.getenv(name);
        if (value == null || value.isBlank()) throw new IllegalArgumentException("Missing environment variable: " + name);
        return value;
    }

    private static String safeFailure(Throwable value, String key) {
        String message = value.getClass().getName() + ": " + String.valueOf(value.getMessage());
        return message.replace(key, "[REDACTED]");
    }

    public static void main(String[] args) throws Exception {
        var result = run(Path.of(args[0]), Path.of(args[1]));
        System.out.println("ok=" + result.get("ok") + "; result=" + Path.of(args[1]).resolve("model-mcp-result.json"));
    }
}
