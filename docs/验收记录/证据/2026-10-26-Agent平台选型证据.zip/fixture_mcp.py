# -*- coding: utf-8 -*-
"""Synthetic, read-only MCP fixture. Never touches the repository knowledge store."""
import hashlib,json,os
from pathlib import Path
from mcp.server.mcpserver import MCPServer
BODY='合成产品手册。订单变更保留版本；供应商在线确认变更内容；采购查看待确认状态。例外：接口未验证，交期及量化收益未知。'
HASH=hashlib.sha256(BODY.encode()).hexdigest()
server=MCPServer('k24-synthetic-knowledge')
def log(name,args):
    directory=Path(os.environ['K24_RUN_DIR'])
    directory.mkdir(parents=True,exist_ok=True)
    with (directory/'mcp_calls.jsonl').open('a') as f:
        f.write(json.dumps({'tool':name,'args':args},ensure_ascii=False)+'\n')
@server.tool()
def search_product_materials(query:str,product:str='',domain:list[str]|None=None,category:str='',limit:int=5)->dict:
    """Search the synthetic product manual; read section_rules when planning exception handling."""
    log('search_product_materials',{'query':query})
    return {'synthetic':True,'corpus':'product_materials','results':[{'material_id':'synthetic-manual','revision':1,'source_sha256':HASH,'section_id':'section_orders','body':'订单变更版本、供应商在线确认、采购查询状态。详细限制请定向读取 section_rules。','related_section_ids':['section_rules']}]}
@server.tool()
def read_product_material(material_id:str,revision:int,source_sha256:str,section_ids:list[str]|None=None,full_document:bool=False)->dict:
    """Read an exact synthetic material version and the requested section. No full read needed."""
    log('read_product_material',{'material_id':material_id,'revision':revision,'source_sha256':source_sha256,'section_ids':section_ids,'full_document':full_document})
    if material_id!='synthetic-manual' or revision!=1 or source_sha256!=HASH:
        raise ValueError('exact version/hash mismatch')
    if full_document or section_ids!=['section_rules']:
        raise ValueError('only targeted section_rules read is supported for this fixture')
    return {'synthetic':True,'material_id':material_id,'revision':revision,'source_sha256':source_sha256,'sections':[{'section_id':'section_rules','body':BODY}]}
if __name__=='__main__':server.run(transport='stdio')
